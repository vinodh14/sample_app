import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({transform: 'translateX(-100%)'}),
        animate('2000ms ease-in', style({transform: 'translateX(0%)'}))
      ]),
      transition(':leave', [
        animate('2000ms ease-in', style({transform: 'translateX(100%)'}))
      ])
    ])
  ]
})
export class ProjectsComponent implements OnInit {

	title: string;
	currentState = 'initial';
	visible: boolean = false;
	
	constructor( private route: ActivatedRoute ) { }

	ngOnInit() {
		this.route.url.subscribe(url => this.title = url[0].path);
		this.animateFunc();
	}
	
	animateFunc(){
		setTimeout(() => {
			this.visible = true;
		}, 2500)
		
		setTimeout(() => {
			this.visible = false;
		}, 5000)
	}
	
}
