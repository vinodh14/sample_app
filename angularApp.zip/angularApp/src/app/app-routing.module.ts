import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { ProjectsComponent } from './projects/projects.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { DefaultComponent } from './default/default.component';
/*import { HomeInnerComponent } from './home/home-inner/home-inner.component';
import { HomeContactComponent } from './home/home-contact/home-contact.component';
import { HomeAboutComponent } from './home/home-about/home-about.component';*/

const routes: Routes = [
	{
		/*path:'home', 
		component: HomeComponent,
		children:[
			{path:'', component: HomeInnerComponent},
			{path:'contact', component: HomeContactComponent},
			{path:'about', component: HomeAboutComponent}
		]*/
		path:'home', loadChildren: './home/home.module#HomeModule'
	},
	{path:'project', component: ProjectsComponent},
	{path:'service', component: ServicesComponent},
	{path:'contact', component: ContactComponent},
	{path:'', component: DefaultComponent},
	{path:'**', component: DefaultComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
