import { Component, OnInit } from '@angular/core';
import { trigger, state, style, animate, transition, keyframes, query, stagger } from '@angular/animations';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css'],
  animations: [
	trigger('animateItems', [
		transition(':enter', [
			query('.col', style({ opacity: 0, transform: 'translateX(-100%)' })),

			query('.col', stagger('500ms', [
				animate('1000ms 1.2s ease-out', style({ opacity: 1, transform: 'translateX(0)' })),
			]))        
		]),
		transition(':leave', [
			query('.col', stagger('-500ms', [
				animate('800ms 1.2s ease-out', style({ opacity: 0, transform: 'translateX(-100%)' })),
			]))
        
		])
    ])
  ]
})
export class ServicesComponent implements OnInit {
	title: string;
	visible: boolean = true;
	
	constructor( private route: ActivatedRoute ) { }

	ngOnInit() {
		this.route.url.subscribe(url => this.title = url[0].path);
		this.animateFunc();
	}
	
	animateFunc(){
		setTimeout(() => {
			this.visible = false;
		}, 3000)
	}

}
