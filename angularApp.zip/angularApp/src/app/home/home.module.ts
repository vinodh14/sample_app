import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { FeatureModule } from '../Feature/feature.module';

import { HomeComponent } from './home.component';
import { HomeInnerComponent } from './home-inner/home-inner.component';
import { HomeContactComponent } from './home-contact/home-contact.component';
import { HomeAboutComponent } from './home-about/home-about.component';

@NgModule({
  imports: [
    CommonModule,
	HomeRoutingModule,
	FeatureModule
  ],
  declarations: [
	HomeComponent,
	HomeInnerComponent,
	HomeContactComponent,
	HomeAboutComponent
  ],
  exports: [
	HomeComponent,
	HomeInnerComponent,
	HomeContactComponent,
	HomeAboutComponent
  ]
})
export class HomeModule { }
