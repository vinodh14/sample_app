import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home.component';
import { HomeInnerComponent } from './home-inner/home-inner.component';
import { HomeContactComponent } from './home-contact/home-contact.component';
import { HomeAboutComponent } from './home-about/home-about.component';

// Define the routes
const homeRoutes: Routes = [
  /*{ path: '', component: HomeComponent },
  { path: 'home/home', component: HomeInnerComponent },
  { path: 'home/contact', component: HomeContactComponent },
  { path: 'home/about', component: HomeAboutComponent }*/
	{ 
		path: '', 
		component: HomeComponent,
		children: [
			{ path: '', component: HomeInnerComponent },
			{ path: 'contact', component: HomeContactComponent },
			{ path: 'about', component: HomeAboutComponent }
		]
	}
];

// In a feature module forChild() method must be used to register routes
// Export RouterModule, so the it's directives like RouterLink, RouterOutlet
// are available to the EmployeeModule that imports this module
@NgModule({
  imports: [ RouterModule.forChild(homeRoutes) ],
  exports: [ RouterModule ]
})
export class HomeRoutingModule { }