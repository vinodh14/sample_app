import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
	
	constructor(private elRef: ElementRef) { }

	@HostListener('mouseenter') onMouseEnter() {
		this.elRef.nativeElement.style.backgroundColor = 'blue';
		this.elRef.nativeElement.style.color = '#fff';
	}

	@HostListener('mouseleave') onMouseLeave() {
		this.elRef.nativeElement.style.backgroundColor = 'transparent';
		this.elRef.nativeElement.style.color = '#333';
	}
}
